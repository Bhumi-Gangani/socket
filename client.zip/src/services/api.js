import axios from "axios";

const apiRequest = async ({
    method,
    url,
    data,
}) => {

    let response = null, error = null
    let options = {
        method: method,
        url: `${process.env.REACT_APP_URL}/${url}`,
        headers: {
            'Accept': 'application/json',
        },
        data: data
    }

    await axios(options)
        .then(res => {
            response = res
        })
        .catch(err => {
            console.error('API ERROR:::', err)
            error = err
        })

    return { response, error }
}

export { apiRequest }