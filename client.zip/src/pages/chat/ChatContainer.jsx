import React from 'react';
import { useSelector } from 'react-redux';
import UserInput from '../../components/UserInput';
import ChatBox from '../../components/ChatBox';
import io from 'socket.io-client';
import './style.css'

const socket = io('http://127.0.0.1:8000')

const ChatContainer = () => {
    const { userId } = useSelector((state) => state.user);

    return (
        <div>
            {!userId ? (
                <UserInput socket={socket} />
            ) : (
                <ChatBox socket={socket} />
            )}
        </div>
    );
};

export default ChatContainer;