import React from 'react';
import { Provider } from 'react-redux';
import { persistor, store } from './store';
import ChatContainer from './pages/chat/ChatContainer';
import { PersistGate } from 'redux-persist/integration/react'

const App = () => {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <div>
          <ChatContainer />
        </div>
      </PersistGate>
    </Provider>
  );
};

export default App;