
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { joinGroup } from '../store/actions/user';

const UserInput = ({ socket }) => {

  const dispatch = useDispatch();

  const [user, setUser] = useState({
    name: '',
    group: ''
  });
  const [err, setErr] = useState('')

  const handleChange = (e) => {
    let { name, value } = e.target
    setUser({ ...user, [name]: value })
  }

  const handleJoin = () => {
    let { name, group } = user
    if (!name || !group) {
      setErr('Name and group are required')
    }
    else {
      setErr('')
      const payload = {
        group,
        user: name
      }
      dispatch(joinGroup(payload, socket));
    }
  };

  return (
    <div className="user-input-container">
      <input
        type="text"
        placeholder="Enter your name"
        name='name'
        value={user.name}
        onChange={handleChange}
        className="input-field"
      />
      <select
        name='group'
        value={user.group}
        onChange={handleChange}
        className="select-field"
      >
        <option value="">Select a group</option>
        <option value="IT">IT</option>
        <option value="sales">Sales</option>
        <option value="HR">HR</option>
      </select>
      <button onClick={handleJoin} className="join-button">
        Join
      </button>
      <p className='error-msg'>{err}</p>
    </div>
  );
};

export default UserInput;
