import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { messageReceived, messageSend, saveHistory } from '../store/actions/chat';
import { leaveGroup } from '../store/actions/user';

const ChatBox = ({ socket }) => {

  const dispatch = useDispatch('')
  const msgContainer = useRef(null);

  const [message, setMessage] = useState('');

  const { name, group, userId: user } = useSelector((state) => state.user);
  const { messages } = useSelector((state) => state.chat);

  const handleMessageSend = () => {
    const newMessage = {
      sender: user,
      message: message,
    };

    // Send the message to the server
    socket.emit('message', newMessage);
    dispatch(messageSend({
      sender: user,
      msg: message,
      // name: name
    }));

    scrollToBottom()
    setMessage('');
  };

  // Send message on enter
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleMessageSend();
    }
  };

  const handleLeave = () => {
    dispatch(leaveGroup())
  }

  const scrollToBottom = () => {
    setTimeout(() => {
      msgContainer.current.scrollTop = msgContainer.current.scrollHeight
    }, 0);
  }

  useEffect(() => {
    // Handle incoming messages
    socket.on('receiveMessage', (data) => {
      dispatch(messageReceived(data));
      scrollToBottom()
    })

    socket.on('history', (data) => {
      dispatch(saveHistory(data?.history));
      scrollToBottom()
    })

    return () => {
      socket.removeListener("receiveMessage");
      socket.removeListener("history");
    }
  }, [user])



  return (
    <div className="chat-box-container">
      <div className="user-info">
        <h2>Welcome, {name}! You are in the {group} group.</h2>
      </div>
      <div className="message-container" ref={msgContainer}>
        {messages?.map((msg, index) => (
          <div key={index} className={`message ${msg.sender === user ? 'send' : ''}`}>
            <div className='sender'>{msg.name}</div>
            <div className='text'>{msg.msg}</div>
          </div>
        ))}
      </div>
      <div className="input-container">
        <input
          type="text"
          placeholder="Type your message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="message-input"
          onKeyPress={handleKeyPress}
        />
        <button onClick={handleMessageSend} className="send-button">
          Send
        </button>
      </div>
      <div className='leave-container'>
        <button onClick={handleLeave} className="leave-button">
          Leave Group
        </button>
      </div>
    </div>
  );
};

export default ChatBox;
