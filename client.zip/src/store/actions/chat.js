import { RECEIVED_MESSAGE, SAVE_HISTORY, SEND_MESSAGE } from "../consts"

export const messageReceived = (message) => {
    return {
        type: RECEIVED_MESSAGE,
        payload: message
    }
}

export const messageSend = (message) => {
    return {
        type: SEND_MESSAGE,
        payload: message
    }
}

export const saveHistory = (message) => {
    return {
        type: SAVE_HISTORY,
        payload: message
    }
}