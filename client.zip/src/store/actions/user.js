import { apiRequest } from "../../services/api"
import { JOIN_GROUP_FAIL, JOIN_GROUP_REQUEST, JOIN_GROUP_SUCCESS, LEAVE_GROUP } from "../consts"

export const joinGroup = (payload, socket) => {
  return async (dispatch) => {
    dispatch({ type: JOIN_GROUP_REQUEST });
    const { response, error } = await apiRequest({
      method: 'POST',
      url: `joinGroup`,
      data: payload,
    })
    if (response) {
      dispatch({ type: JOIN_GROUP_SUCCESS, payload: response?.data })
      socket.emit('authenticate', response?.data?.userId);
    }
    else if (error) {
      dispatch({ type: JOIN_GROUP_FAIL })
    }
  }
}

export const leaveGroup = () => {
  return async (dispatch) => {
      dispatch({ type: LEAVE_GROUP });
  }
}