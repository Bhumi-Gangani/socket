import { JOIN_GROUP_FAIL, JOIN_GROUP_REQUEST, JOIN_GROUP_SUCCESS, LEAVE_GROUP } from "../consts";

const initialState = {
  name: null,
  group: null,
  userId: null,
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case JOIN_GROUP_REQUEST:
      return {
        ...state,
        ...initialState
      };
    case JOIN_GROUP_SUCCESS:
      const { group, user, userId } = action.payload || {}
      return {
        ...state,
        name: user,
        group,
        userId,
      };
    case JOIN_GROUP_FAIL:
      return {
        ...state,
        ...initialState
      };
      case LEAVE_GROUP:
      return {
        ...state,
        ...initialState
      };

    default:
      return state;
  }
};

export default userReducer;