import { RECEIVED_MESSAGE, SAVE_HISTORY, SEND_MESSAGE } from "../consts";

const initialState = {
  messages: [],
};

const chatReducer = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVED_MESSAGE:
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };
    case SEND_MESSAGE:
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };
    case SAVE_HISTORY:
      return {
        ...state,
        messages: [...action.payload],
      };
    default:
      return state;
  }
};

export default chatReducer;