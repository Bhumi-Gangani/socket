import { combineReducers } from 'redux';
import chatReducer from './chat';
import userReducer from './user';
import { persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage'

const persistConfig = {
  key: 'root',
  storage,
  whitelist: ['user']
}

const rootReducer = combineReducers({
  chat: chatReducer,
  user: userReducer
});

const persistedReducer = persistReducer(persistConfig, rootReducer)

export default persistedReducer;
