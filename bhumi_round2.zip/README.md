# Chat App Using MERN & socket.io - Bhumi Gangani

## Getting started

Create database in local : chatapp

### TO run client:

cd client 
npm install
npm start

### To run server:

cd server
npm install
npm run dev
