const express = require('express');
const { createServer } = require('node:http');
const { join } = require('node:path');
const { Server } = require('socket.io');
const cors = require('cors');
const User = require('./src/models/user');
const { v4: uuidv4 } = require('uuid');
const Message = require('./src/models/message');
const { log } = require('node:console');
require('./src/db/connection')

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000"
  }
})
app.use(cors())
app.use(express.json())

const groups = ['IT', 'HR', 'sales']


//! API routes and ctrls
app.get('/', (req, res) => {
  res.send('SERVER IS RUNNING...')
})

app.post('/joinGroup', async (req, res) => {
  const { group, user } = req.body

  if (!user || !group || !groups.includes(group)) {
    return res.status(400).send({
      success: false,
      message: "Invalid payload",
    })
  }

  //Create unique userID
  const userId = uuidv4();

  //Save user
  try {
    const newUser = new User({
      userId,
      user,
      group
    })
    const data = await newUser.save()

    return res.send({
      userId, group, user,
      success: true,
    })
  } catch (err) {
    return res.status(400).send({
      success: false,
      message: err
    })
  }
})


//! Socket event handling
const groupChat = io.of('/')
groupChat.on('connection', (socket) => {
  console.log('user connected...')

  socket.on('authenticate', async (userId) => {
    groupChat.sockets.set(userId, socket);
    const userData = await User.findOne({
      userId
    })
    socket.join(userData.group);

    const messages = await Message.find({
      group: userData.group
    })

    socket.emit('history', {
      history: messages
    })

  });

  socket.on('message', async (data) => {
    const { sender: userId, message } = data || {}
    const userData = await User.findOne({
      userId
    })
    const newMessage = new Message({
      sender: userId,
      group: userData.group,
      msg: message,
    })
    await newMessage.save()

    socket.to(userData.group).emit('receiveMessage', {
      sender: userId,
      msg: message,
      name: userData.user
    })
  });

});


server.listen(8000, () => {
  console.log('server running at http://localhost:8000');
});