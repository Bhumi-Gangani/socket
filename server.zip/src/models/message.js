const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  sender: String,
  group: String,
  msg: String,
});

const Message = mongoose.model('message', messageSchema);

module.exports = Message;